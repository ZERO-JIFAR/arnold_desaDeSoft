package com.facu.tpPersist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpPersistApplicationTests {

	@Test
	void contextLoads() {
	}

}
