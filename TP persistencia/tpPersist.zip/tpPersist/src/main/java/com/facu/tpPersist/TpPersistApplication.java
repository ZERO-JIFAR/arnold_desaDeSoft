package com.facu.tpPersist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpPersistApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpPersistApplication.class, args);
	}

}
